-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2024 at 06:56 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `coffee_sales`
--

CREATE TABLE `coffee_sales` (
  `id` int(11) NOT NULL,
  `pname` varchar(250) NOT NULL,
  `price` int(250) NOT NULL,
  `qty` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coffee_sales`
--

INSERT INTO `coffee_sales` (`id`, `pname`, `price`, `qty`) VALUES
(1, 'Nescafe', 20, 1),
(2, 'Kopiko Brown', 15, 1),
(3, 'Great taste White', 15, 1),
(4, 'Cappucino', 120, 1),
(5, 'Mocha', 240, 1),
(6, 'Americano', 200, 2),
(7, 'Cappuccino', 250, 1),
(8, 'Latte', 275, 3),
(9, 'Espresso', 180, 2),
(10, 'Macchiato', 220, 1),
(11, 'Flat White', 260, 1),
(12, 'Irish Coffee', 320, 2),
(13, 'Affogato', 300, 1),
(14, 'Cortado', 240, 2),
(15, 'Ristretto', 190, 1),
(16, 'Turkish Coffee', 210, 1),
(17, 'Vienna Coffee', 280, 2),
(18, 'Drip Coffee', 150, 3),
(19, 'Cold Brew', 250, 2),
(20, 'Nitro Cold Brew', 300, 1),
(21, 'Iced Americano', 220, 2),
(22, 'Iced Latte', 290, 1),
(23, 'Iced Mocha', 310, 1),
(24, 'Espresso Con Panna', 210, 3),
(25, 'Red Eye', 230, 1),
(26, 'Black Eye', 250, 1),
(27, 'Cafe Au Lait', 220, 2),
(28, 'Flat White Iced', 270, 1),
(29, 'Caramel Latte', 310, 2),
(30, 'Hazelnut Latte', 300, 2),
(31, 'Pumpkin Spice Latte', 350, 1),
(32, 'Matcha Latte', 330, 1),
(33, 'Chai Latte', 290, 2),
(34, 'White Chocolate Mocha', 350, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coffee_sales`
--
ALTER TABLE `coffee_sales`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coffee_sales`
--
ALTER TABLE `coffee_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
